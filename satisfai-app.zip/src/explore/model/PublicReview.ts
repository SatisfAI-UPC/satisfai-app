export interface Review {
    id: number;
    title: string;
    description: string;
}