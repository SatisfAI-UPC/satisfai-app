export interface SigninRequest {
    email: string;
    password: string;
}