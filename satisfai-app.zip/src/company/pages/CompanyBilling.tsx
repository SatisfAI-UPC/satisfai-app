

function CompanyBilling() {
    return (
        <div>
            <h1 className="page-title">Billing</h1>
        </div>
    );
};

export default CompanyBilling;