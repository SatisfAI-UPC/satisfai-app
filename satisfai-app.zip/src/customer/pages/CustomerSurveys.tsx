
function CustomerSurveys() {
    return (
        <div>Customer Survey Page</div>
    );
}

export default CustomerSurveys;