

function CustomerProfile() {
    return (
        <div>Customer Profile Page</div>
    );
}

export default CustomerProfile;