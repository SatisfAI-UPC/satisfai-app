

function CustomerReviews() {
    return (
        <div>Customer Reviews Page</div>
    );
}

export default CustomerReviews;