
export interface CreateSurveyResponse {
    givenRespondent: number;
    answers: Record<string, string>;
}